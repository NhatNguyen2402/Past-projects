"""
Subcontroller module for Alien Invaders

This module contains the subcontroller to manage a single level or wave in the Alien
Invaders game.  Instances of Wave represent a single wave.  Whenever you move to a
new level, you are expectsed to make a new instance of the class.

The subcontroller Wave manages the ship, the aliens and any laser bolts on screen.  
These are model objects.  Their classes are defined in models.py.

Most of your work on this assignment will be in either this module or models.py.
Whether a helper method belongs in this module or models.py is often a complicated
issue.  If you do not know, ask on Piazza and we will answer.

Karen Zhou (kz265) & Nguyen Minh Nhat (nmn44)
12/5/17
"""
from game2d import *
from consts import *
from models import *
import random

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Wave is NOT allowed to access anything in app.py (Subcontrollers are not permitted 
# to access anything in their parent. To see why, take CS 3152)


class Wave(object):
	"""
	This class controls a single level or wave of Alien Invaders.
	
	This subcontroller has a reference to the ship, aliens, and any laser bolts on screen. 
	It animates the laser bolts, removing any aliens as necessary. It also marches the
	aliens back and forth across the screen until they are all destroyed or they reach
	the defense line (at which point the player loses). When the wave is complete, you 
	should create a NEW instance of Wave (in Invaders) if you want to make a new wave of 
	aliens.
	
	If you want to pause the game, tell this controller to draw, but do not update.  See 
	subcontrollers.py from Lecture 24 for an example.  This class will be similar to
	than one in how it interacts with the main class Invaders.
	
	#UPDATE ME LATER
	INSTANCE ATTRIBUTES:
		_ship:   the player ship to control [Ship]
		_aliens: the 2d list of aliens in the wave [rectangular 2d list of Alien or None] 
		_bolts:  the laser bolts currently on screen [list of Bolt, possibly empty]
		_dline:  the defensive line being protected [GPath]
		_lives:  the number of lives left  [int >= 0]
		_time:   The amount of time since the last Alien "step" [number >= 0]
	
	As you can see, all of these attributes are hidden.  You may find that you want to
	access an attribute in class Invaders. It is okay if you do, but you MAY NOT ACCESS 
	THE ATTRIBUTES DIRECTLY. You must use a getter and/or setter for any attribute that 
	you need to access in Invaders.  Only add the getters and setters that you need for 
	Invaders. You can keep everything else hidden.
	
	You may change any of the attributes above as you see fit. For example, may want to 
	keep track of the score.  You also might want some label objects to display the score
	and number of lives. If you make changes, please list the changes with the invariants.
	
	LIST MORE ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
		_moveRight: True if aliens should be moving right, False if moving left [boolean]
		_isPlayerBolt: True if player has fired a bolt that is still on screen, False if not
						fired or bolt is deleted [boolean]
		_boltRate: number of steps til next alien fire [int >=1 and =<BOLT_RATE]
		_numSteps: number of steps aliens have taken since last firing [int >= 0]
		_outcome: True if won, False if lost, initially None [boolean]
		_lifeLost: True if life was just lost, False otherwise [boolean]
		
		Extensions:
		_alienspeed: The speed of the aliens [int or float>=0]
		_display: Displays level, lives left, and score from killing aliens [GLabel]
		_score: Numerical score from killing aliens [int>=0]
		_level: Level of the current wave [int>=1]
	"""
	
	# GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM')'	
	def getScore(self):
		"""
		Returns ship score		
		"""
		return self._score

	def getOutcome(self):
		"""
		Returns value of attribute _outcome, a boolean representing win/loss/ongoing
		"""
		return self._outcome
	
	def setShip(self):
		"""
		Sets _ship to new Ship() object
		"""
		self._ship = Ship()
		
	def setlifeLost(self):
		"""
		Sets _lifeLost to False to reset the attribute
		"""
		self._lifeLost = False
		
	def getlifeLost(self):
		"""
		Returns value of _lifelost, boolean representing if a life was just lost
		"""
		return self._lifeLost
	
	def getLives(self):
		"""
		Returns value of _lives, int representing lives left
		"""
		return self._lives
	
	def setSpeed(self, level):
		"""
		Sets _alienspeed to ALIEN_SPEED*(0.5**(level-1))
		
		Parameter level: level of current wave
		Precondition: level is an int >=1
		"""
		self._alienspeed = ALIEN_SPEED*(0.5**(level-1))
		
	def _set_aliens(self):
		"""
		Sets attribute _aliens, a 2d list of aliens in the wave
		"""
		alienlist = []
		k = 0
		for row in range(ALIEN_ROWS):
			rowofaliens = []
			for col in range(ALIENS_IN_ROW):
				x = ALIEN_WIDTH/2 + ALIEN_H_SEP*(col+1)+(ALIEN_WIDTH*col)
				#x = ALIEN_H_SEP*(col+1) + ALIEN_WIDTH*(col+1)
				y = (GAME_HEIGHT-ALIEN_CEILING-(ALIEN_HEIGHT*(ALIEN_ROWS-(row+1)))
					 -(ALIEN_V_SEP*(ALIEN_ROWS-(row+1))))
				rowofaliens.append(Alien(x, y, ALIEN_IMAGES[k]))
				#print('alien position at x='+repr(x)+' y='+repr(y))
			alienlist.append(rowofaliens)
			if(row%2 == 1 and k < 2):
				k += 1
			elif(row%2 == 1 and k==2):
				k = 0
		
		self._aliens = alienlist
			
	# INITIALIZER (standard form) TO CREATE SHIP AND ALIENS
	def __init__(self, lives, score, level):
		"""
		Initializer: Creates a Wave
		
		Wave contains the ship, aliens, bolts, etc. involved in gameplay
		
		Parameter lives: ship lives during this wave
		Precondition: lives is an int >=0
		
		Parameter score: score at beginning of wave
		Precondition: score is an int or float >= 0
		
		Parameter level: current wave level
		Precondition: level is an int >=1
		"""
		self._set_aliens()
		# for row in range(ALIEN_ROWS):
		# 	for col in range(ALIENS_IN_ROW):
		# 		print(repr(self._aliens[row][col].x)+', '+repr(self._aliens[row][col].y))
		self._ship = Ship()
		self._dline = GPath(points=[0,DEFENSE_LINE,GAME_WIDTH,DEFENSE_LINE],linewidth=1, linecolor='green')
		self._time = 0
		self._moveRight = True
		self._bolts = []
		self._isPlayerBolt = False
		self._boltRate = random.randint(1,BOLT_RATE)
		self._numSteps = 0
		self._lives = lives
		self._outcome = None
		self._lifeLost = False
		self._alienspeed = ALIEN_SPEED
		self._score = score
		self._level = level
		self._display = GLabel(text=("Level " + repr(self._level)
					+"        "+"Lives left: "+repr(self.getLives())
					+"        "+"Score: "+repr(self.getScore())),
					font_size = 25, font_name = 'Arcade', x=X_DISPLAY, y=Y_DISPLAY,linecolor='green')
		
	# UPDATE METHOD TO MOVE THE SHIP, ALIENS, AND LASER BOLTS
	def update(self, inp, dt):
		"""
		Updates the Wave object
		
		Parameter inp: The input 
		Precondition: inp is a GInput
		
		Parameter dt: The time in seconds since last update
		Precondition: dt is a number (int or float)
		"""
		self._moveShip(inp)
		self._time += dt 
		if(self._time >= self._alienspeed): #ALIEN_SPEED): #doesn't move at start when time = 0
			self._moveAliens()
			self._numSteps += 1
			self._time = 0
		self._moveBolts(inp)
		self._collision()
		
		numAlive = 0
		crossedLine = False
		for row in self._aliens:
			for alien in row:
				if alien!=None:
					numAlive+=1
				if alien!= None and alien.getY()-ALIEN_HEIGHT/2 < DEFENSE_LINE:
					crossedLine = True
					
		if(self._lives == 0 or crossedLine == True): #over, lost
			#print('outcome false')
			self._outcome = False
		elif(numAlive == 0): #over, won
			#print('outcome true')
			self._outcome = True
		
	def _moveShip(self, inp):
		"""
		Helper function to update that moves the ship
	
		Parameter inp: The input 
		Precondition: inp is a GInput
		"""
		#move ship
		if(self._ship != None and inp.is_key_down('left')):
			new_X = self._ship.getX() - SHIP_MOVEMENT
			x = max(SHIP_WIDTH, new_X)
			self._ship.setX(x)
		elif(self._ship != None and inp.is_key_down('right')):
			new_X = self._ship.getX() + SHIP_MOVEMENT
			x = min(GAME_WIDTH-SHIP_WIDTH, new_X)
			self._ship.setX(x)
	
	def _moveAliens(self):
		"""
		Helper function to update that moves aliens
		"""
		new_X = self._findnewX()
		if(self._moveRight == True and new_X < GAME_WIDTH - ALIEN_H_SEP - ALIEN_WIDTH): #keep moving right
			#print('moving right')
			for row in range(ALIEN_ROWS):
				for alien in self._aliens[row]:
					if(alien!=None):
						x = alien.getX() + ALIEN_H_WALK
						alien.setX(x)
		elif(self._moveRight == True and new_X >= GAME_WIDTH - ALIEN_H_SEP - ALIEN_WIDTH): #move down
			#print('moving down')
			for row in range(ALIEN_ROWS):
				for alien in self._aliens[row]:
					if(alien!=None):
						y = alien.getY() - ALIEN_V_WALK
						alien.setY(y)
			self._moveRight = False # move left now
		elif(self._moveRight == False and new_X > ALIEN_H_SEP + ALIEN_WIDTH): #move left
			for row in range(ALIEN_ROWS):
				for alien in self._aliens[row]:
					if(alien!=None):
						x = alien.getX() - ALIEN_H_WALK
						alien.setX(x)
		elif(self._moveRight == False and new_X <= ALIEN_H_SEP + ALIEN_WIDTH): #move down
			for row in range(ALIEN_ROWS):
				for alien in self._aliens[row]:
					if(alien!=None):
						y = alien.getY() - ALIEN_V_WALK
						alien.setY(y)
			self._moveRight = True
		#27 lines! Within 30 lines!!
			
	def _findnewX(self):
		"""
		Helper function to the helper _moveAliens that determines position of rightmost
		or leftmost alien column
		"""
		if(self._moveRight == True):
			j = 1
			while j <= ALIENS_IN_ROW: #already at top row
				k=1
				while k <= ALIEN_ROWS:
					if self._aliens[ALIEN_ROWS-k][ALIENS_IN_ROW-j] != None:
						new_X = self._aliens[ALIEN_ROWS-k][ALIENS_IN_ROW-j].x + ALIEN_H_WALK
						k = ALIEN_ROWS+1
						j = ALIENS_IN_ROW+1
					#print('j = 1')
					else: #move to new row
						k += 1
					#print('new col for j ' + repr(j))
				j+=1
				k=1
		else: #move left
			j = 0
			while j < ALIENS_IN_ROW:
				k=1
				while k <= ALIEN_ROWS:
					if self._aliens[ALIEN_ROWS-k][j] != None:#top row
						new_X = self._aliens[ALIEN_ROWS-k][j].x - ALIEN_H_WALK
						k = ALIEN_ROWS+1
						j = ALIENS_IN_ROW
					else: #move to new row
						k += 1
					#print('new col for j ' + repr(j))
				j+=1
		return new_X
				
	def _moveBolts(self,inp):
		"""
		Creates bolts, appends them to _bolts, moves them, and deletes them
		
		Parameter inp: The input 
		Precondition: inp is a GInput
		"""
		#print('numsteps ' + repr(self.numSteps) + ' boltrate '+ repr(self.boltRate))
		if(self._numSteps == self._boltRate): #create alien bolt
			firingAlien = self._randomAliens()
			newABolt = Bolt(firingAlien.getX(),firingAlien.getY()-ALIEN_HEIGHT/2, False)
			self._bolts.append(newABolt)
			#print('added alien bolt, len' + repr(len(self._bolts)))
		
		if(self._ship!=None and inp.is_key_down('up') and self._isPlayerBolt == False):#create player bolt
			self._isPlayerBolt = True
			newBolt = Bolt(self._ship.getX(),SHIP_HEIGHT, self._isPlayerBolt)
			self._bolts.append(newBolt)
		for bolt in self._bolts:#move
			bolt.moveBolt()				
		
		#delete bolts; code referenced from pyro.py
		i = 0
		while i < len(self._bolts):
			if self._bolts[i].getY() > GAME_HEIGHT+BOLT_HEIGHT/2: #player bolt 
				del self._bolts[i]
				#print('player bolt deleted')
				self._isPlayerBolt = False #can shoot again
			elif self._bolts[i].getY() < 0: #alien bolts
				del self._bolts[i]
				#print('alien bolt deleted')
			else:
				i += 1
			
	def _randomAliens(self):
		"""
		Returns randomly generated Alien object in the _aliens list
		"""
		pos = 0
		column = 0 #change later
		 
		#check for non-None columns & random select
		nonemptyCol = []
		for col in range(ALIENS_IN_ROW):
			numNone = 0
			for row in range(ALIEN_ROWS):
				if(self._aliens[row][col]  == None):
					numNone+=1
			if(numNone != ALIEN_ROWS):
				nonemptyCol.append(col)
		
		column = random.choice(nonemptyCol)
		#non-None bottom of column
		
		while self._aliens[pos][column] == None:
			pos+=1
			
		self._numSteps = 0
		self._boltRate = random.randint(1,BOLT_RATE)
		
		return self._aliens[pos][column]
	
	# DRAW METHOD TO DRAW THE SHIP, ALIENS, DEFENSIVE LINE AND BOLTS
	def draw(self, view):
		"""
		Draws the ellipse to the application window (view).
		
		Parameter: The view window
		Precondition: view is a GView.
		"""
		#print("wave draw running")
		for row in self._aliens:
			for alien in row:
				#print(repr(alien.x)+', '+repr(alien.y))
				if alien!= None:
					alien.draw(view)
		
		#print('drawing ship')
		if self._ship!=None:
			self._ship.draw(view)
		#print('drawing line')		
		self._dline.draw(view)
		for bolt in self._bolts:
			if bolt!=None:
				bolt.draw(view)		
		self._display.draw(view)
				
	# HELPER METHODS FOR COLLISION DETECTION
	def _collision(self):
		"""
		Detects collisions of bolts with aliens and ships
		"""
		i = 0
		while i < len(self._bolts):
			bolt = self._bolts[i]
			if(self._ship!=None and self._ship.collides(bolt) == True):
				self._ship = None
				#print('collision w ship detected')
				self._lives-=1
				self._lifeLost = True
				self._display.text = ("Level " + repr(self._level)
							+"        "+"Lives left: "+repr(self.getLives())
							+"        "+"Score: "+repr(self.getScore()))
				del self._bolts[i]
				i = len(self._bolts) #end loop
			else:
				i+=1
		
		j=0
		while j < len(self._bolts):
			bolt = self._bolts[j]
			for row in range(ALIEN_ROWS):
				for col in range(ALIENS_IN_ROW):
					alien = self._aliens[row][col]
					if(alien != None and alien.collides(bolt) == True):
						# print('collision w alien  '+ repr(row) + ',' + repr(col)+' detected'
						# 	  +'\n alien corners: ')
						self._scoreKeep(self._aliens[row][col])
						self._aliens[row][col] = None
						del self._bolts[j]
					#	print('player bolt deleted thru alien collisoon')
						self._isPlayerBolt = False
						self._display.text = ("Level " + repr(self._level)
							+"        "+"Lives left: "+repr(self.getLives())
							+"        "+"Score: "+repr(self.getScore()))

			j+=1
		#27 lines
			
	def _scoreKeep(self, alien):
		"""
		Calculates player score and assigns to _score
		
		Alien worth is determined by how far from the defense line they are per 100 pixels
		
		Parameter alien: the Alien that got shot
		Precondition: alien is an Alien
		"""
		scoreFactor = ((GAME_HEIGHT-ALIEN_CEILING)//(ALIEN_HEIGHT+ALIEN_V_SEP)
			-alien.getY()//(ALIEN_HEIGHT+ALIEN_V_SEP))
		#print('scoreFactor '+ repr(scoreFactor))
		if(scoreFactor!=0):
			score = scoreFactor*5
		else:
			score = 1
		self._score += score
					
